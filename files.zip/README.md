# Suhail AI — Personal Chatbot

Developed by **Mohd Suhail** · Software Engineer · AI & ML

---

## Setup Instructions

### 1. Install dependencies

```bash
pip install -r requirements.txt
```

### 2. Add your OpenAI API Key

Open `app.py` and replace:
```python
API_KEY = "your-openai-api-key-here"
```
with your actual OpenAI API key.

### 3. Run the app

```bash
python app.py
```

Then open your browser and go to: **http://localhost:5000**

---

## Features

- 💬 **Text Chat** — Full conversation with GPT-4o
- 🎙️ **Voice Chat** — Speak and get spoken replies
- 🔊 **6 AI Voices** — 3 Male (Alloy, Echo, Onyx) · 3 Female (Nova, Shimmer, Fable)
- 🌐 **Whisper** — Accurate speech-to-text transcription
- ✨ **Premium UI** — Dark themed, animated, professional interface

---

## API Features Used

| Feature | OpenAI Model |
|---|---|
| Text Chat | `gpt-4o` |
| Speech-to-Text | `whisper-1` |
| Text-to-Speech | `tts-1` |

---

> Note: Voice Chat requires microphone permission in your browser.
