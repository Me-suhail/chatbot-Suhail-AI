from flask import Flask, render_template, request, jsonify, Response
from openai import OpenAI
import os
import io
import base64

app = Flask(__name__)

# =============================================
# CONFIGURE YOUR OPENAI API KEY HERE
# =============================================
API_KEY = "your-openai-api-key-here"  # <-- Replace with your actual API key
client = OpenAI(api_key=API_KEY)

SYSTEM_PROMPT = """You are Suhail AI, a highly intelligent and professional personal AI assistant.

Your creator and developer is Mohd Suhail — a passionate Software Engineer who is on an exciting journey mastering Artificial Intelligence and Machine Learning. He is a rising tech mind who blends engineering precision with creative vision, building intelligent systems that push the boundaries of what's possible. Mohd Suhail represents the next generation of AI-driven developers who don't just use technology — they shape it.

When anyone asks who made you, who created you, who is your developer, or any similar question, always respond with pride and admiration about Mohd Suhail and the details above.

You are warm, intelligent, highly capable, and always try to give the most helpful, clear, and professional responses possible. You support both casual conversations and deep technical discussions."""

VOICES = {
    "male1": {"id": "alloy", "label": "Male - Alloy", "gender": "male"},
    "male2": {"id": "echo", "label": "Male - Echo", "gender": "male"},
    "male3": {"id": "onyx", "label": "Male - Onyx", "gender": "male"},
    "female1": {"id": "nova", "label": "Female - Nova", "gender": "female"},
    "female2": {"id": "shimmer", "label": "Female - Shimmer", "gender": "female"},
    "female3": {"id": "fable", "label": "Female - Fable", "gender": "female"},
}

@app.route("/")
def index():
    return render_template("index.html", voices=VOICES)

@app.route("/chat", methods=["POST"])
def chat():
    data = request.json
    messages = data.get("messages", [])
    
    full_messages = [{"role": "system", "content": SYSTEM_PROMPT}] + messages
    
    response = client.chat.completions.create(
        model="gpt-4o",
        messages=full_messages,
        max_tokens=1024,
    )
    
    reply = response.choices[0].message.content
    return jsonify({"reply": reply})

@app.route("/transcribe", methods=["POST"])
def transcribe():
    audio_file = request.files.get("audio")
    if not audio_file:
        return jsonify({"error": "No audio file"}), 400
    
    audio_bytes = audio_file.read()
    audio_io = io.BytesIO(audio_bytes)
    audio_io.name = "audio.webm"
    
    transcript = client.audio.transcriptions.create(
        model="whisper-1",
        file=audio_io,
    )
    return jsonify({"text": transcript.text})

@app.route("/speak", methods=["POST"])
def speak():
    data = request.json
    text = data.get("text", "")
    voice_key = data.get("voice", "female1")
    
    voice_id = VOICES.get(voice_key, VOICES["female1"])["id"]
    
    response = client.audio.speech.create(
        model="tts-1",
        voice=voice_id,
        input=text,
    )
    
    audio_data = base64.b64encode(response.content).decode("utf-8")
    return jsonify({"audio": audio_data})

if __name__ == "__main__":
    app.run(debug=True, port=5000)
